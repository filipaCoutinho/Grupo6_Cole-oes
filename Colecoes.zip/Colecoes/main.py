import tkinter as tk
from tkinter import ttk

def janela_gestao_colecao():
    janela_principal.withdraw()  # Esconder a principal
    janela = tk.Toplevel()
    janela.title("Gestão de Coleção")

    ttk.Label(janela, text="Aqui vai o conteúdo da coleção").pack(pady=20)
    ttk.Button(janela, text="Voltar", command=lambda: [janela.destroy(), janela_principal.deiconify()]).pack(pady=10)

janela_principal = tk.Tk()
janela_principal.title("Janela Principal")

ttk.Button(janela_principal, text="Abrir Coleção", command=janela_gestao_colecao).pack(pady=50)

janela_principal.mainloop()

