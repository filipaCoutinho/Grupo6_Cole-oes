import mysql.connector
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import json
from datetime import date, datetime
from tkinter import messagebox, filedialog


#-----------------------------------------LIGAÇÃO A BASE DE DADOS ----------------------------------------

# E efetuado a ligação a base de dados atraves da criação de uma funçao, onde e colocado todos as
# credenciais para a sua ligação

def obter_conexao():
    return mysql.connector.connect(
        host="192.168.56.102",
        user="jorge",
        password="jorge@",
        database="colecoesdb",
        port=3306
    )


#------------------------------------FUNÇAO DE EXPORTAR --------------------------------------------------

def exportar_para_json(tabela):
    try:  # efetua a ligaçao a base de dados, onde sera feita um select de toda a tabela
        conexao = obter_conexao()
        cursor = conexao.cursor(dictionary=True)  # Alterado de 'cur' para 'cursor'
        cursor.execute(f"SELECT * FROM {tabela}")
        resultados = cursor.fetchall()
        conexao.close()

        # usamos uma estrutura de controlo IF para verificar se existe resposta a resultar
        if not resultados:
            messagebox.showinfo("Info", "A coleção está vazia, nada para exportar.")
            return
        # E criada a função CONVERTER, que converte os objetos com formatação de data, em strings
        def converter(obj):
            if isinstance(obj, (date, datetime)):
                return obj.isoformat()
            return obj
        # e criado uma lista vazia , que vai receber os resultados do ciclo FOR,e acrescenta
        # nodicionario" novoitem "
        resultados_convertidos = []
        for item in resultados:
            novo_item = {chave: converter(valor) for chave, valor in item.items()}
            resultados_convertidos.append(novo_item)

        # Indica o caminho onde o ficheiro a ser criado , e indica a extensão qdo ficheiro
        # indica o nome, bem como verifica se o ficheiro se encontra vazio

        caminho = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("Arquivos JSON", "*.json")],
            title="Salvar coleção como JSON"
        )
        if not caminho:
            return
        # tenta abrir o ficheiro, com a capacidade de escrita, e em caso que seja sucesso
        # e apresentado uma mensagem
        with open(caminho, "w", encoding="utf-8") as f:
            json.dump(resultados_convertidos, f, indent=4, ensure_ascii=False) #

        messagebox.showinfo("Sucesso", "Coleção exportada para JSON com sucesso.")

    # caso não seja possivel escrever no ficheiro, e emitida uma mensagem de erro

    except Exception as e:
        messagebox.showerror("Erro", f"Falha ao exportar coleção:\n{e}")

#---------------------------FUNÇAO DE IMPORTAR FICHEIRO JSON --------------------------------------------

# Nesta função iremos defenir a funcionalidade de o utilizador poder fazer a importação de ficheiros
# json para a nossa base de dados

def importar_de_json(tabela, voltar_atualizar=None):
    try: # tenta abrir o ficheiro Json, atraves da abertura de uma janela onde o utilizador pode escolher o
        # o ficheiro, caso não escolha nenhum ficheiro, nao retorna nada
        caminho = filedialog.askopenfilename(filetypes=[("Arquivos JSON", "*.json")],
                                             title=f"Importar dados para {tabela}")
        if not caminho:
            return
        # tenta abrir o ficheiro escolhido, em modo de leitura
        with open(caminho, "r", encoding="utf-8") as f:
            dados = json.load(f)
        # caso não seja possivel, ler o ficheiro, retorna uma mensagem de erro de abertura
        if not dados:
            messagebox.showinfo("Info", "Arquivo vazio, nao existe nada para importar.")
            return
        # faz a conexao ao, base de dados
        conexao = obter_conexao()
        cursor = conexao.cursor()

        # E actualiza a base de dados com, os dados existentes no ficheiro, esvaziando a
        # base de dados atraves do comando TRUNCATE
        cursor.execute(f"TRUNCATE TABLE {tabela}")
        conexao.commit()
        campos = {
            "jogos": ["nome", "tipo", "ano", "observacoes"],
            "livros": ["pais", "titulo", "autor", "tema", "ano"]
        }[tabela]

        # atraves de um cicrculo FOR, verifica, que os dados inseridos, estao corretos.
        # e verifica se a chave "ano" existe no dicionario "item"

        for item in dados:
            if "ano" in item:
                if isinstance(item["ano"], str): # altera e o campo "ano" em string
                    try:
                        # formata o campo" ano "em anos simples
                        if len(item["ano"]) == 4:
                            item["ano"] = f"{item['ano']}-01-01"
                        item["ano"] = datetime.strptime(item["ano"], "%Y-%m-%d").date()
                        # Caso dê erro, ignora o erro
                    except ValueError:
                        pass
            # faz a inserção dos dados na base de dados atraves da instrução em SQL " JOIN "
            placeholders = ", ".join(["%s"] * len(campos))
            query = f"INSERT INTO {tabela} ({', '.join(campos)}) VALUES ({placeholders})"
            valores = [item.get(campo, None) for campo in campos]
            cursor.execute(query, valores)


        conexao.commit() # confirma a inserçao dos dados na base de dados
        conexao.close() # fecha a ligação a base de dados
        # informação de sucesso
        messagebox.showinfo("Sucesso", f"Dados importados para {tabela}!")

        if voltar_atualizar:
            voltar_atualizar()
    # informação de erro, caso não tenha sido possivel a introdução dos dados na base de dados
    except Exception as e:
        messagebox.showerror("Erro", f"Falha ao importar:\n{e}")
        if conexao:
            conexao.rollback()
            conexao.close()

#---------------------------------- FUNÇAO DE PESQUISA --------------------------------------------

# Esta função tem como objetivo buscar dados numa tabela específica da base de dados,
# com a opção de aplicar filtros baseados no nome e/ou no tipo.

def procurar(table, filtro_nome=None, filtro_tipo=None):
    # estabelece a ligação a base de dados
    conexao = obter_conexao()
    cursor = conexao.cursor()
    query = f"SELECT * FROM {table}"
    parametros = []

    # Verifica se algum filtro (por nome ou por tipo) foi fornecido.

    if filtro_nome or filtro_tipo:
        # Se houver algum filtro, adiciona a cláusula WHERE à consulta SQL.
        if filtro_nome:
            # Adiciona uma condição para procurar nomes que contenham a string fornecida (LIKE %valor%).
            query += " nome LIKE %s"
            # Adiciona o valor do filtro de nome à lista de parâmetros, com os carateres '%' para correspondência parcial.
            parametros.append(f"%{filtro_nome}%")
            # Se também houver um filtro por tipo, adiciona o operador lógico AND para combinar as condições.
            if filtro_tipo:
                query += " AND"
        if filtro_tipo:
            # Determina o nome da coluna a ser usada para o filtro de tipo, que é 'tipo' para a tabela 'jogos'
            # e 'tema' para outras tabelas.
            campo = "tipo" if table == "jogos" else "tema"
            # Adiciona a condição para procurar valores na coluna de tipo/tema que contenham a string fornecida.
            query += f" {campo} LIKE %s"
            # Adiciona o valor do filtro de tipo à lista de parâmetros, com os carateres '%' para correspondência parcial.
            parametros.append(f"%{filtro_tipo}%")
    # Executa a consulta SQL com os parâmetros fornecidos. O cursor lida com a substituição segura dos parâmetros.
    # e fecha a ligação a base de dados
    cursor.execute(query, parametros)
    dados = cursor.fetchall()
    conexao.close()
    return dados

#-------------------------------- GESTAO GRAFICA -----------------------------------------------------
# Funçao que elabora a parte grafica da janela da gestão da coleções


def janela_gestao_colecao(tabela):
    janela_principal.withdraw()
    janela = tk.Toplevel()
    janela.title(f"Gestão de {'Jogos' if tabela == 'jogos' else 'Livros'}") # atribuição do titulo a janela

    # definição do tamanho da janela (como sendo largura e altura
    largura_tela = janela.winfo_screenwidth()
    altura_tela = janela.winfo_screenheight()
    largura_janela = largura_tela // 2
    altura_janela = altura_tela // 2
    pos_x = (largura_tela - largura_janela) // 2
    pos_y = (altura_tela - altura_janela) // 2
    janela.geometry(f"{largura_janela}x{altura_janela}+{pos_x}+{pos_y}")
    janela.minsize(800, 400)
    janela.resizable(True, True)

    # Configuração do janela  principal ( tamanho )
    janela.grid_rowconfigure(1, weight=1)
    janela.grid_columnconfigure(0, weight=1)

    campos = {
        "jogos": ["id", "nome", "tipo", "ano", "observacoes"],
        "livros": ["id", "pais", "titulo", "autor", "tema", "ano"]
    }

    colunas = campos[tabela]

    # Configuração do estilo da Treeview, que se trata de uma funcionalidade existe dentro da biblioteca
    # Tkinter,e que permite ter semelhanças com o EXcel, muito usado para visualização de informação
    # em tabelas e colunas
    style = ttk.Style()
    style.configure("Treeview", font=('Tahoma', 10), rowheight=25)
    style.configure("Treeview.Heading", font=('Tahoma', 10, 'bold'))
    style.map('Treeview', background=[('selected', '#347083')])

    tree = ttk.Treeview(janela, columns=colunas[1:], show="headings", style="Treeview")
    for coluna in colunas[1:]:
        tree.heading(coluna, text=coluna)
        tree.column(coluna, width=100, anchor='w')
    # defeniçao quando a informação e superior ao tamanho da janela , e ecrescentado uma Scrollbar
    # para navegar na informação apresentada

    linhas_verticais = ttk.Scrollbar(janela, orient="vertical", command=tree.yview)
    linhas_horizontais = ttk.Scrollbar(janela, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=linhas_verticais.set, xscrollcommand=linhas_horizontais.set)

    # definições a caixa de filtros
    caixa_filtros = tk.Frame(janela)
    caixa_filtros.grid(row=0, column=0, columnspan=2, sticky='ew', padx=10, pady=5)

    if tabela == "jogos":
        ttk.Label(caixa_filtros, text="Nome:").grid(row=0, column=0, padx=5)
        filtro_nome = ttk.Entry(caixa_filtros, width=30)
        filtro_nome.grid(row=0, column=1, padx=5)

        ttk.Label(caixa_filtros, text="Tipo:").grid(row=0, column=2, padx=5)
        filtro_tipo = ttk.Entry(caixa_filtros, width=30)
        filtro_tipo.grid(row=0, column=3, padx=5)
    else:
        ttk.Label(caixa_filtros, text="Autor:").grid(row=0, column=0, padx=5)
        filtro_autor = ttk.Entry(caixa_filtros, width=30)
        filtro_autor.grid(row=0, column=1, padx=5)

        ttk.Label(caixa_filtros, text="País:").grid(row=0, column=2, padx=5)
        filtro_pais = ttk.Entry(caixa_filtros, width=30)
        filtro_pais.grid(row=0, column=3, padx=5)

    # configurações do botoes , neste caso ' filtrar ' , quer a cor da letra , tipo , tamanho .
    btn_filtrar = tk.Button(
        caixa_filtros,
        text="Filtrar", # texto
        command=lambda: carregar_dados(),
        bg='lightgreen', # cor do botão
        fg='white', # cor da letra
        activebackground='lightblue', # cor quando e pressionado
        font=('Tahoma', 10) # tipo de letra
    )
    btn_filtrar.grid(row=0, column=4, padx=5),



    # defenições do Treeview e scrollbars
    tree.grid(row=1, column=0, sticky='nsew', padx=10, pady=5)
    linhas_verticais.grid(row=1, column=1, sticky='ns')
    linhas_horizontais.grid(row=2, column=0, sticky='ew')

    # Caracteristicas dos botões principais
    botoes_frame = tk.Frame(janela)
    botoes_frame.grid(row=3, column=0, columnspan=2, sticky='ew', padx=10, pady=10)

    # Atraves do circulo for, efetua a verificação que todos os botoes sao identicos conforma as
    # dimensoes da janela
    for i in range(6):
        botoes_frame.columnconfigure(i, weight=1)

    # Lista de botões de cada janela das coleções ,
    botoes = [
        ("Adicionar", lambda: adicionar()),
        ("Alterar", lambda: editar()),
        ("Apagar", lambda: remover()),
        ("Exportar JSON", lambda: exportar_para_json(tabela)),
        ("Importar JSON", lambda: importar_de_json(tabela, carregar_dados)),
        ("Voltar", lambda: [janela.destroy(), janela_principal.deiconify()])
    ]

    # Defenições dos botoes, tamanho, cor estilo de letra , etc
    for i, (texto, comando) in enumerate(botoes):
        btn = tk.Button(
            botoes_frame,  # Alterado de 'botoes' para 'botoes_frame'
            text=texto,
            command=comando,
            width=15,
            height=2,
            font=('Tahoma', 10),
            bg='lightgreen',
            fg='Black',
            activebackground='lightblue'
        )
        btn.grid(row=0, column=i, padx=5, sticky='ew')

        


  #------------------------------- FUNÇOES DE GESTÃO ---------------------------------------------
        # Nesta etapa iremos efetuar a ligação dos botoes anteriormente criados, com a funcionalidade
        # desenvolvida, para cada um deles

        # Esta função ira fazer a ligação a base de dados para alimentar a tabela, existente em cada janela
        # com as colecões

    def carregar_dados():
        #Limpa todos os dados existente na janela grafica
        tree.delete(*tree.get_children())

        if tabela == "jogos":
            # Vai buscar os tados a tabela "jogos" da base de dados, mas filtrado por nome e tipo
            dados = procurar(tabela, filtro_nome.get(), filtro_tipo.get())

        else:
            # liga-se a base de dados, na tabela "Livros"
            conexao = obter_conexao()
            cursor = conexao.cursor()
            query = "SELECT * FROM livros WHERE 1=1"
            parametros = []
            # Aplica filtro por autor
            if filtro_autor.get():
                query += " AND autor LIKE %s"
                parametros.append(f"%{filtro_autor.get()}%")
            if filtro_pais.get():
                query += " AND pais LIKE %s"
                parametros.append(f"%{filtro_pais.get()}%")

            # Executa uma query com os parâmetros e fecha a ligação a base de dados
            cursor.execute(query, parametros)
            dados = cursor.fetchall()
            conexao.close()

        for linha in dados:
            tree.insert("", tk.END, iid=linha[0], values=linha[1:]) # inser todos os dados á excepção
            # do ID
        # Funçao de abertura da janela de visualização dos dados da base de dados, bem com a separação
        # campos
    def abrir_janela_edicao(mode='adicionar', item_id=None):
        janela_operacao = tk.Toplevel(janela)
        janela_operacao.title("Adicionar" if mode == 'adicionar' else "Editar")
        janela_operacao.transient(janela)
        janela_operacao.grab_set()

        # definições da janela e posicionamento  ( altura e largura )
        largura_janela_op = 400
        altura_janela_op = 350 if tabela == "livros" else 300
        horizontal_main = janela.winfo_x()
        vertical_main = janela.winfo_y()
        largura_main = janela.winfo_width()
        altura_main = janela.winfo_height()
        horizontal_posicao = horizontal_main + (largura_main - largura_janela_op) // 2
        vertical_posicao = vertical_main + (altura_main - altura_janela_op) // 2
        janela_operacao.geometry(f"{largura_janela_op}x{altura_janela_op}+{horizontal_posicao}+{vertical_posicao}")
        janela_operacao.resizable(False, False)

        frame_principal = tk.Frame(janela_operacao)
        frame_principal.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

        # Define os campos a exibir consoante a coleção escolhida
        campos_form = {
            "jogos": ["nome", "tipo", "ano", "observacoes"],
            "livros": ["pais", "titulo", "autor", "tema", "ano"]
        }[tabela]

        entradas = {}
        for i, campo in enumerate(campos_form):
            tk.Label(frame_principal, text=campo.capitalize() + ":").grid(row=i, column=0, sticky='e', padx=5, pady=5)
            entrada = tk.Entry(frame_principal)
            entrada.grid(row=i, column=1, sticky='ew', padx=5, pady=5)
            entradas[campo] = entrada

        if mode == 'editar' and item_id:
            conexao = obter_conexao()
            cursor = conexao.cursor()
            cursor.execute(f"SELECT * FROM {tabela} WHERE id = %s", (item_id,))
            dados_item = cursor.fetchone()
            conexao.close()

            for i, campo in enumerate(campos_form):
                valor = dados_item[i + 1] if i + 1 < len(dados_item) else ""
                if campo == "ano" and isinstance(valor, (date, datetime)):
                    entradas[campo].insert(0, valor.strftime("%Y-%m-%d"))
                else:
                    entradas[campo].insert(0, str(valor) if valor is not None else "")

        frame_principal.columnconfigure(1, weight=1)

        botoes = tk.Frame(janela_operacao)
        botoes.pack(pady=10, fill=tk.X)


        # Funçao Salvar, salva os dados inseridos pelo o utilizador

        def salvar():
            valores = {}
            for campo in campos_form:
                valor = entradas[campo].get().strip()

                # Verifica se os campos estão todos preenchidos
                if not valor and not (tabela == "jogos" and campo == "observacoes"):
                    messagebox.showwarning("Aviso", f"O campo {campo} não pode estar vazio!")
                    return

                if campo == "ano":
                    if len(valor) == 4 and valor.isdigit():
                        valor = f"{valor}-01-01"
                    elif not (len(valor) == 10 and valor.count("-") == 2):
                        messagebox.showerror("Erro", "Formato de data inválido. Use YYYY ou YYYY-MM-DD.")
                        return

                valores[campo] = valor

            try: # coneta a base de dados
                conexao = obter_conexao()
                cursor = conexao.cursor()

                    # query que permite a inserçao dos dados inseridos
                if mode == 'adicionar':
                    campos_sql = ", ".join(valores.keys())
                    placeholders = ", ".join(["%s"] * len(valores))
                    query = f"INSERT INTO {tabela} ({campos_sql}) VALUES ({placeholders})"
                    cursor.execute(query, tuple(valores.values()))
                else:
                    campos_update = ", ".join([f"{campo} = %s" for campo in valores.keys()])
                    query = f"UPDATE {tabela} SET {campos_update} WHERE id = %s"
                    cursor.execute(query, (*valores.values(), item_id))

                conexao.commit()
                messagebox.showinfo("Sucesso", "Operação realizada com sucesso!")
                janela_operacao.destroy()
                carregar_dados()

                # verificação se existe erro na inserção, indicando atraves de mensagem, e desfaz toda
                # a informação introduzida
            except Exception as e:
                messagebox.showerror("Erro", f"Falha na operação:\n{e}")
                conexao.rollback()
            finally:# fecha a ligação a base de dados
                conexao.close()

        # defenição do botão "Salvar "
        btn_salvar = tk.Button(botoes, text="Salvar", command=salvar, width=20, height=2)
        btn_salvar.pack(side=tk.RIGHT, padx=5)
        # defenição do botao " cancelar
        btn_cancelar = tk.Button(botoes, text="Cancelar", command=janela_operacao.destroy, width=20, height=2)
        btn_cancelar.pack(side=tk.RIGHT, padx=5)

    def adicionar(): # abertura de Janela # Adicionar
        abrir_janela_edicao(mode='adicionar')

    def editar(): # Abre a janela Editar , caso haja dados seleccionados
        item = tree.selection()
        if not item:
            messagebox.showwarning("Editar", "Selecione um item.")
            return
        abrir_janela_edicao(mode='editar', item_id=item[0])

    # Função Remover, remove os dados selecionados apos confirmação
    def remover():
        item = tree.selection()
        if not item:
            messagebox.showwarning("Remover", "Selecione um item.")
            return
        if messagebox.askyesno("Confirmar", "Deseja remover este item?"):
            conexao = obter_conexao()
            cursor = conexao.cursor()
            cursor.execute(f"DELETE FROM {tabela} WHERE id = %s", (item[0],))
            conexao.commit()
            conexao.close()
            carregar_dados()

    carregar_dados()

# Janela  Principal , e defenições desde tamanho, altura
janela_principal = tk.Tk()
janela_principal.title("Gestão de Coleções")

largura_tela = janela_principal.winfo_screenwidth()
altura_tela = janela_principal.winfo_screenheight()
largura_janela = largura_tela // 2
altura_janela = altura_tela // 2
pos_x = (largura_tela - largura_janela) // 2
pos_y = (altura_tela - altura_janela) // 2

janela_principal.geometry(f"{largura_janela}x{altura_janela}+{pos_x}+{pos_y}")
janela_principal.minsize(800, 400)
janela_principal.resizable(True, True)

caixa_principal = tk.Frame(janela_principal)
caixa_principal.pack(expand=True, pady=20)

# Configurações da Janela Principal, bem como texto
ttk.Label(caixa_principal, text="Escolha a Coleção", font=("Tahoma", 22)).pack(pady=20)

# Defenicões do botao de Jogos existente na Janela principal
btn_jogos = tk.Button(caixa_principal, text="Coleção de Jogos",
                      command=lambda: janela_gestao_colecao("jogos"),
                      width=20, height=2, font=('Tahoma', 12),
                      bg='lightgreen', fg='black', activebackground='lightblue')
btn_jogos.pack(pady=10)

# Defenicões do botao de Livros existente na Janela principal
btn_livros = tk.Button(caixa_principal, text="Coleção de Livros",
                       command=lambda: janela_gestao_colecao("livros"),
                       width=20, height=2, font=('Tahoma', 12),
                       bg='lightgreen', fg='black', activebackground='lightblue')
btn_livros.pack(pady=10)

# Defenicões do botao de Sair  existente na Janela principal
btn_sair = tk.Button(caixa_principal, text="Sair",
                     command=janela_principal.destroy,
                     width=20, height=2, font=('Tahoma', 10),
                     bg='lightgreen', fg='black', activebackground='red')
btn_sair.pack(pady=20)


janela_principal.mainloop()